package com.recycler.agendacontactos.presenters.mostrar;

public interface IMostrarContactoPresenter {

    void mostrarContacto(int id);
    void eliminarContacto(int id);

}
