package com.recycler.agendacontactos.presenters.listar;

import com.recycler.agendacontactos.models.Contacto;

public interface IListaContactosFragmentPresenter {

    void obtenerContactos();

    void mostrarContactosRV();
}
